# À mon rythme sur iPhone

L’application réunit 34 fiches illustrées et un journal. Elle fonctionne hors ligne et garde les journées sur l’iPhone. Les liens vers les sources s’ouvrent dans le navigateur quand tu les touches. iOS 17 ou plus récent est requis.

## Installer avec Xcode

1. Sur le Mac, décompresse l’archive, puis ouvre **A_Mon_Rythme.xcodeproj** dans Xcode.
2. Dans **Xcode → Settings → Accounts**, ajoute ton compte Apple si nécessaire.
3. Dans le projet, sélectionne la cible **Carnet**, ouvre **Signing & Capabilities**, puis choisis ton équipe dans **Team**. Un compte Apple gratuit peut apparaître comme **Personal Team**.
4. Connecte et déverrouille l’iPhone, accepte de faire confiance au Mac si iOS le demande, puis sélectionne l’iPhone dans le menu à côté du bouton **▶** de Xcode.
5. Clique sur **▶**. Si Xcode demande le mode développeur, suis l’instruction sur l’iPhone dans **Réglages → Confidentialité et sécurité → Mode développeur**, puis relance depuis Xcode après le redémarrage.

Avec une équipe personnelle gratuite, le profil d’installation expire après sept jours. Relance l’installation depuis le même projet pour renouveler le profil. Exporte régulièrement une sauvegarde avant de supprimer l’application ou de changer d’appareil.

## Récupérer les journées du Mac

1. Dans l’ancien carnet, ouvre **Sauvegarder ou restaurer mon carnet** et choisis **Exporter une sauvegarde**.
2. Transfère le fichier JSON sur l’iPhone, par exemple avec AirDrop, puis garde-le dans **Fichiers**.
3. Dans l’appli, ouvre **Sauvegarder ou restaurer mon carnet → Importer une sauvegarde**, puis sélectionne le JSON. Les journées déjà présentes sur l’iPhone sont conservées si elles portent la même date.

Pour conserver une copie de tes données iPhone, utilise **Exporter une sauvegarde**, puis sélectionne **Enregistrer dans Fichiers** dans le menu Partager.

[Compte Apple et équipe personnelle](https://developer.apple.com/help/account/basics/about-your-developer-account) · [Mode développeur](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device/)

## Thème et Apple Santé

Le bouton **Thème** propose **Comme l’iPhone**, **Clair** et **Sombre**. Dans **Exercices**, touche **Abdos**, **Pompes**, **Pilates**, **Qi gong**, **Tai-chi** ou **Yoga doux** pour voir les fiches correspondantes. Chaque fiche montre deux positions, des consignes et une variante plus douce. Les sources et précautions figurent dans le catalogue.

Pour transmettre une journée, enregistre-la dans **Journal**, puis ouvre **Suivi → Apple Santé → Envoyer la journée sélectionnée**. Indique l’heure réelle des données que tu souhaites envoyer. Pour les séances, indique leur heure de début. Au premier envoi, iOS te demande les autorisations d’écriture. L’application peut écrire le poids, la fatigue et les séances chronométrées. Pour la fatigue, elle transmet aucune à 0, légère de 1 à 3, modérée de 4 à 6 et sévère de 7 à 10. Le carnet garde ton score exact, tes notes, la douleur et les mouvements cochés.

[Autorisations Apple Santé](https://developer.apple.com/documentation/healthkit/authorizing-access-to-health-data)


## Programme journalier · version 1.9

Dans **Journal**, touche un chiffre de 0 à 10 sur la ligne **Douleur actuelle**, puis sur la ligne **Fatigue actuelle**. Pour la gêne dans les gestes, la douleur habituelle, la vigilance, la récupération et les signaux inhabituels, touche directement la réponse illustrée. Le carnet peut proposer du repos, une séance assise progressive, avec un format allégé, ou une séance avec pédalier à faible résistance. Chaque étape affiche un pictogramme et sa durée. Touche-la pour voir les deux dessins et la consigne sur place. Le retour au calme est compris dans la durée affichée, tandis que le journal comptabilise les minutes de mouvement par activité. La case **Options, poids et note** active le pédalier s’il t’a déjà été conseillé par un soignant et que tu le tolères encore.

Après l’enregistrement, le programme du jour reste consultable. **Modifier mon bilan** te ramène aux réponses. Le programme se recalcule à chaque changement et **Enregistrer mon bilan** garde les nouvelles réponses avec les durées déjà notées.

Chaque exercice affiche sa durée conseillée. Saisis ou corrige tes minutes sous la séance, dans **Autres durées réalisées**. Elles sont regroupées par activité. Touche **Enregistrer mon bilan** pour garder tes minutes, ou **J’ai fait la séance** si tu as suivi toutes les durées conseillées. Laisse les champs vides pour enregistrer uniquement le bilan.

Quand le bilan est stable, **Choisir l’activité** permet de préférer la marche à plat ou le tapis. La marche à plat suppose que tu la pratiques déjà sans instabilité. Le tapis suppose que ton équilibre a été évalué, que le tapis t’a été conseillé et que tu le tolères. La durée commence à 5 min de marche et peut monter à 20 min. Pour chaque mode de marche et pour le pédalier, la progression dépend de trois séances au même niveau avec récupération confirmée le lendemain. Les signaux d’alerte prennent toujours le dessus sur les notes chiffrées. Les seuils numériques et le rythme du carnet sont des repères prudents et n’ont pas été validés comme barème médical individuel. Le bloc reste disponible dans le journal, et les fiches de renforcement dans le catalogue, avec leurs précautions.

Sur un bilan stable, **Séance assise** commence à 7 minutes, retour au calme compris. Après trois séances au même niveau enregistrées avec **J’ai fait la séance** et bien récupérées le lendemain, le carnet ajoute une minute, jusqu’à 10 minutes. Une séance écourtée ou un contrecoup peut réduire le repère. Le format allégé de 3 minutes affiche les réponses qui l’ont déclenché.
