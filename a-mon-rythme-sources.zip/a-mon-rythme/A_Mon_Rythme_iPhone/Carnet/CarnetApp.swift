import SwiftUI
import UIKit
import UniformTypeIdentifiers
import WebKit

@main
struct CarnetApp: App {
    var body: some Scene {
        WindowGroup {
            CarnetScreen()
        }
    }
}

private struct CarnetScreen: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> CarnetController {
        CarnetController()
    }

    func updateUIViewController(_ controller: CarnetController, context: Context) {}

    static func dismantleUIViewController(_ controller: CarnetController, coordinator: ()) {
        controller.disconnect()
    }
}

@MainActor
private final class CarnetController: UIViewController, WKNavigationDelegate, WKUIDelegate,
    WKScriptMessageHandlerWithReply, UIDocumentPickerDelegate
{
    private let maxBackupBytes = 5_000_000
    private let appearanceKey = "carnet.appearance"
    private var page: URL?
    private var webView: WKWebView?
    #if HEALTHKIT_ENABLED
    private let healthJournal = HealthJournal()
    private let healthAvailable = true
    #else
    private let healthAvailable = false
    #endif
    private var importReply: ((Any?, String?) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 11/255, green: 18/255, blue: 32/255, alpha: 1)
                : UIColor(red: 244/255, green: 247/255, blue: 252/255, alpha: 1)
        }
        guard let url = Bundle.main.url(forResource: "Carnet", withExtension: "html") else {
            showLoadError()
            return
        }

        page = url
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "carnet")
        configureBootstrap(configuration.userContentController)
        let browser = WKWebView(frame: .zero, configuration: configuration)
        browser.navigationDelegate = self
        browser.uiDelegate = self
        browser.isOpaque = false
        browser.backgroundColor = .clear
        browser.underPageBackgroundColor = .clear
        browser.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(browser)
        NSLayoutConstraint.activate([
            browser.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            browser.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            browser.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            browser.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
        ])
        webView = browser
        browser.loadFileURL(url, allowingReadAccessTo: url)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        applyAppearance()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        applyAppearance()
    }

    private enum Appearance: String {
        case system, light, dark

        var interfaceStyle: UIUserInterfaceStyle {
            switch self {
            case .system: .unspecified
            case .light: .light
            case .dark: .dark
            }
        }
    }

    private var appearance: Appearance {
        Appearance(rawValue: UserDefaults.standard.string(forKey: appearanceKey) ?? "") ?? .system
    }

    private func applyAppearance() {
        overrideUserInterfaceStyle = appearance.interfaceStyle
        view.window?.overrideUserInterfaceStyle = appearance.interfaceStyle
    }

    private func configureBootstrap(_ controller: WKUserContentController) {
        controller.removeAllUserScripts()
        controller.addUserScript(WKUserScript(
            source: "window.carnetAppearance = '\(appearance.rawValue)'; window.carnetHealth = \(healthAvailable);",
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        ))
    }

    func disconnect() {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "carnet", contentWorld: .page)
    }

    private func showLoadError() {
        let label = UILabel()
        label.text = "Le carnet n’a pas pu s’ouvrir."
        label.font = .preferredFont(forTextStyle: .body)
        label.adjustsFontForContentSizeCategory = true
        label.textColor = .label
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor),
            label.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
        ])
    }

    private func dataFile() throws -> URL {
        let base = try FileManager.default.url(
            for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true
        )
        var directory = base.appendingPathComponent("CarnetPrive", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        return directory.appendingPathComponent("journal.json")
    }

    private func readText(_ url: URL) throws -> String {
        if let bytes = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize, bytes > maxBackupBytes {
            throw CocoaError(.fileReadTooLarge)
        }
        let data = try Data(contentsOf: url)
        guard data.count <= maxBackupBytes, let text = String(data: data, encoding: .utf8) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        return text
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage,
        replyHandler: @escaping (Any?, String?) -> Void
    ) {
        guard message.frameInfo.isMainFrame,
            let url = message.frameInfo.request.url,
            isCarnetPage(url),
            let request = message.body as? [String: Any],
            let action = request["action"] as? String
        else {
            replyHandler(nil, "Action non autorisée.")
            return
        }

        do {
            switch action {
            case "appearance":
                guard let value = request["value"] as? String, let mode = Appearance(rawValue: value) else {
                    replyHandler(nil, "Thème inconnu.")
                    return
                }
                UserDefaults.standard.set(mode.rawValue, forKey: appearanceKey)
                applyAppearance()
                configureBootstrap(userContentController)
                replyHandler(true, nil)
            #if HEALTHKIT_ENABLED
            case "health":
                guard let day = request["day"] as? String,
                    day.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil,
                    let text = request["text"] as? String, text.utf8.count < 5000,
                    let items = try? JSONDecoder().decode([HealthJournalItem].self, from: Data(text.utf8)),
                    items.count <= 7, Set(items.map(\.key)).count == items.count
                else {
                    replyHandler(nil, "Données de la journée invalides.")
                    return
                }
                Task {
                    do { replyHandler(try await healthJournal.send(items, on: day), nil) }
                    catch { replyHandler(nil, "Santé n’a pas accepté l’envoi.") }
                }
            #endif
            case "read":
                do {
                    replyHandler(try readText(dataFile()), nil)
                } catch let error as NSError where error.domain == NSCocoaErrorDomain
                    && error.code == NSFileReadNoSuchFileError {
                    replyHandler(NSNull(), nil)
                }
            case "write":
                guard let text = request["text"] as? String, text.utf8.count <= maxBackupBytes else {
                    replyHandler(nil, "Le carnet dépasse la taille autorisée.")
                    return
                }
                try Data(text.utf8).write(to: dataFile(), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                replyHandler(true, nil)
            case "import":
                guard presentedViewController == nil, importReply == nil else {
                    replyHandler(nil, "Un autre panneau est déjà ouvert.")
                    return
                }
                importReply = replyHandler
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
                picker.delegate = self
                present(picker, animated: true)
            case "export":
                guard presentedViewController == nil,
                    let date = request["date"] as? String,
                    date.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil
                else {
                    replyHandler(nil, "La sauvegarde ne peut pas être ouverte.")
                    return
                }
                try presentBackup(date: date, reply: replyHandler)
            default:
                replyHandler(nil, "Action inconnue.")
            }
        } catch {
            replyHandler(nil, "Impossible d’accéder au carnet ou au fichier sélectionné.")
        }
    }

    private func presentBackup(date: String, reply: @escaping (Any?, String?) -> Void) throws {
        let source = try dataFile()
        let text = FileManager.default.fileExists(atPath: source.path)
            ? try readText(source)
            : #"{"version":1,"cleared":false,"entries":{}}"#
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let file = folder.appendingPathComponent("Carnet_A_Mon_Rythme_\(date).json")
        do {
            try Data(text.utf8).write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        } catch {
            try? FileManager.default.removeItem(at: folder)
            throw error
        }

        let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = view
        share.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        share.completionWithItemsHandler = { _, completed, _, error in
            try? FileManager.default.removeItem(at: folder)
            reply(completed, error == nil ? nil : "Le partage a échoué.")
        }
        present(share, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let reply = importReply else { return }
        importReply = nil
        guard let url = urls.first else {
            reply(NSNull(), nil)
            return
        }
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        do {
            reply(try readText(url), nil)
        } catch {
            reply(nil, "Impossible de lire cette sauvegarde JSON.")
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        let reply = importReply
        importReply = nil
        reply?(NSNull(), nil)
    }

    private func isCarnetPage(_ url: URL) -> Bool {
        guard url.isFileURL, let page else { return false }
        return url.resolvingSymlinksInPath().path == page.resolvingSymlinksInPath().path
    }

    func webView(
        _ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if isCarnetPage(url) {
            decisionHandler(.allow)
            return
        }
        decisionHandler(.cancel)
        if navigationAction.navigationType == .linkActivated && ["https", "tel"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        }
    }

    func webView(
        _ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void
    ) {
        let alert = UIAlertController(title: "À mon rythme", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Annuler", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "Continuer", style: .default) { _ in completionHandler(true) })
        guard presentedViewController == nil else {
            completionHandler(false)
            return
        }
        present(alert, animated: true)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if let page { webView.loadFileURL(page, allowingReadAccessTo: page) }
    }
}

#if HEALTHKIT_ENABLED
import HealthKit

private struct HealthJournalItem: Decodable {
    let key: String
    let start: Double
    let value: Double
}

@MainActor
private final class HealthJournal {
    private let store = HKHealthStore()
    private let activities: [String: HKWorkoutActivityType] = [
        "bike": .cycling, "walk": .walking, "climb": .climbing,
        "stretch": .flexibility, "strength": .functionalStrengthTraining,
    ]

    private struct Entry {
        let key: String
        let type: HKSampleType
        let start: Date
        let value: Double
        let workout: HKWorkoutActivityType?
    }

    func send(_ items: [HealthJournalItem], on day: String) async throws -> [String: Int] {
        let entries = try items.map(entry)
        guard HKHealthStore.isHealthDataAvailable(), !entries.isEmpty else {
            throw CocoaError(.featureUnsupported)
        }

        try await store.requestAuthorization(toShare: Set(entries.map(\.type)), read: [])
        var saved = 0
        var refused = 0
        var failed = 0
        for entry in entries {
            guard store.authorizationStatus(for: entry.type) == .sharingAuthorized else {
                refused += 1
                continue
            }
            do {
                try await save(entry, day: day)
                saved += 1
            } catch {
                failed += 1
            }
        }
        return ["saved": saved, "refused": refused, "failed": failed]
    }

    private func entry(_ item: HealthJournalItem) throws -> Entry {
        let start = Date(timeIntervalSince1970: item.start)
        guard item.start.isFinite, item.value.isFinite,
            start >= Date(timeIntervalSince1970: 946684800), start <= Date()
        else { throw CocoaError(.fileReadCorruptFile) }

        if let workout = activities[item.key], (1...300).contains(item.value),
            item.value.rounded() == item.value, start.addingTimeInterval(item.value * 60) <= Date() {
            return Entry(key: item.key, type: .workoutType(), start: start, value: item.value, workout: workout)
        }
        if item.key == "weight", (20...500).contains(item.value),
            let type = HKQuantityType.quantityType(forIdentifier: .bodyMass) {
            return Entry(key: item.key, type: type, start: start, value: item.value, workout: nil)
        }
        if item.key == "fatigue", (0...10).contains(item.value), item.value.rounded() == item.value,
            let type = HKCategoryType.categoryType(forIdentifier: .fatigue) {
            return Entry(key: item.key, type: type, start: start, value: item.value, workout: nil)
        }
        throw CocoaError(.fileReadCorruptFile)
    }

    private func save(_ entry: Entry, day: String) async throws {
        var metadata: [String: Any] = [
            HKMetadataKeySyncIdentifier: "fr.remimunier.amonrythme.\(day).\(entry.key)",
            HKMetadataKeySyncVersion: Int(Date().timeIntervalSince1970 * 1000),
            HKMetadataKeyWasUserEntered: true,
        ]
        if let workout = entry.workout {
            let config = HKWorkoutConfiguration()
            config.activityType = workout
            config.locationType = entry.key == "bike" || entry.key == "climb" ? .indoor : .unknown
            let builder = HKWorkoutBuilder(healthStore: store, configuration: config, device: nil)
            try await builder.beginCollection(at: entry.start)
            try await builder.addMetadata(metadata)
            try await builder.endCollection(at: entry.start.addingTimeInterval(entry.value * 60))
            _ = try await builder.finishWorkout()
        } else if let weight = entry.type as? HKQuantityType {
            let sample = HKQuantitySample(type: weight, quantity: HKQuantity(unit: .gramUnit(with: .kilo), doubleValue: entry.value),
                start: entry.start, end: entry.start, metadata: metadata)
            try await store.save(sample)
        } else if let fatigue = entry.type as? HKCategoryType {
            let score = Int(entry.value)
            let severity: HKCategoryValueSeverity
            switch score {
            case 0: severity = .notPresent
            case 1...3: severity = .mild
            case 4...6: severity = .moderate
            default: severity = .severe
            }
            metadata["fr.remimunier.amonrythme.fatigue-sur-10"] = score
            let sample = HKCategorySample(type: fatigue, value: severity.rawValue, start: entry.start, end: entry.start, metadata: metadata)
            try await store.save(sample)
        }
    }
}
#endif
